"Cosmic Alien"  -  TrueType Font
Copyright (c) 2001 by ck!  [Freaky Fonts].  All rights reserved

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is send to me.
Contact: ck@freakyfonts.de
These font files may not be modified or renamed.
This readme file must be included with each font, unchanged.
Redistribute? Sure, but contact me first.

If you like the font, please mail: 
ck@freakyfonts.de

Visit .:Freaky Fonts:. for updates and new fonts (PC & MAC) :
http://www.freakyfonts.de
http://www.geocities.com/Area51/Shadowlands/7677/

Thanks to {ths} for the Mac conversion.
ths@purified.org or visit: http://www.ths.nu

Note:
Paintshop use: Size 6 (& multiplier) - antialising turned off
Photoshop use: Size 8 (& multiplier) - antialising turned off

This font includes some dingbats, cut & paste:  ������

All trademarks are property of their respective owners.